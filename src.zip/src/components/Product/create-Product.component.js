import React, { Component } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";
import "react-datepicker/dist/react-datepicker.css";
import swal from "@sweetalert/with-react";
import Navbar from "../../components/navbar.component"



export default class CreateProduct extends Component {
    constructor(props) {
        super(props);

        
        this.onChangeSupid = this.onChangeSupid.bind(this);
        this.onChangeSupcontact = this.onChangeSupcontact.bind(this);
        this.onChangePid= this.onChangePid.bind(this);
        this.onChangeQty = this.onChangeQty.bind(this);
        this.onChangePname = this.onChangePname.bind(this);
        this.onSubmit = this.onSubmit.bind(this);


        this.state = {
            Supid: "",
            Supcontact: "",
            Pid:"",
            Qty: "",
            Pname: "",
            Product: [],
        };
    }
   
   

  
  //set the Supid

  onChangeSupid(e) {
    this.setState({
        Supid: e.target.value,
    });
}

//set the Supcontact

onChangeSupcontact(e) {
    this.setState({
        Supcontact: e.target.value,
    });
}

//set Pid
onChangePid(e) {
    this.setState({
        Pid: e.target.value,
    });
}

//set qty




onChangeQty(e) {
    this.setState({
        Qty: e.target.value,
    });

   
}



//set Pname
onChangePname(e) {
    this.setState({
        Pname: e.target.value,
    });
}



    //submit Function

    onSubmit(e) {
        e.preventDefault();
        
        const { Supid} = this.state;
        const Product = {
            Supid: this.state.Supid,
            Supcontact: this.state.Supcontact,
            Pid: this.state.Pid,
            Pname: this.state.Pname,
            Qty: this.state.Qty,
               
            };

            console.log(Product);

            if (Supid.length < 4) {
                swal("Supid invalid !", "Supid should be greater than 4", "error");
            } else {

            axios
                .post("http://localhost:5000/Product/add", Product)
                .then((res) => console.log(res.data));

            swal({
                title: "Done!",
                text: "Create Successfully!",
                icon: "success",
                button: "Okay!",
            }).then((value) => {
                swal((window.location = "/Product/"));
            });
            }
    }

    render() {
        return (<div  >
         
           <div class = "row ">
           <div class = "col-6" >
           <br/>
           <img src="https://www.oliverwyman.com/content/dam/oliver-wyman/v2/tmp/industrial-products-mobile.gif" width="80%" height="40%" />
           </div> <div class = "col-6" >
           <div div class = "myformstyle" >
           <div className = "card-body" >
           <div className = "col-md-8 mt-4 mx-auto" > </div> 
           <h3 className = "text-center" > 
           <font face = "Comic sans MS" size = "6" > Add Product </font>
           </h3 > <br></br>
           
           <br></br>
           
            <form onSubmit = { this.onSubmit } >

            



           
           <div className = "form-group" >
          
           <label >Supplier Id: </label> 
          
           <input type = "text"
           placeholder = "Supplier Id"
           required  className = "form-control"
           value = { this.state.Supid }
           onChange = { this.onChangeSupid }/>
            </div > 
            
             

           <div className = "form-group" >
           <label > Supplier Contact No: </label> 
           <input type = "text"
           placeholder = "Supplier Contact No"
           required  className = "form-control"
           value = { this.state.Supcontact }
           onChange = { this.onChangeSupcontact }/>
            </div > 

           


            <div className = "form-group" >
            <label > Product Id: </label> 
            <input type = "text"
            placeholder = "Product Id"
            required  className = "form-control"
            value = { this.state.Pid }
            onChange = { this.onChangePid}/>
             </div > 

             
            <div className = "form-group" >
           <label > Product name: </label> 
           <input type = "text"
           placeholder = "Product name"
           required  className = "form-control"
           value = { this.state.Pname }
           onChange = { this.onChangePname }/>
            </div >

            <div className = "form-group" >
           <label > Qty: </label> 
           <input type = "number"
           placeholder = "Qty"
           required  className = "form-control"
           value = { this.state.Qty }
           onChange = { this.onChangeQty }/>
            </div >


           


           <div className = "form-group" >
           <input type = "submit"
           value = "Create "
           className = "btn btn-primary" />
           </div>{" "} </form >  </div> </div > </div>
            </div ><br/> <br/>  </div>
        );
    }
}