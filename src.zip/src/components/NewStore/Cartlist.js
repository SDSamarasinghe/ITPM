import React, { Component } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Button } from "react-bootstrap";

const Cart = (props) => ( 
    <tr>
    <td > { props.Cart.No } </td> 
    <td> {props.Cart.name} </td > { " " } 
    <td > { props.Cart.id  } </td>{" "}
    <td > { props.Cart.name } </td> 
    <td > { props.Cart.age } </td> 
   

   
     </tr>
);

export default class CartList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            Amount : "",
            Cart: [],
        };
    }

    componentDidMount() {
        axios
            .get("http://localhost:5000/Cart/")
            .then((response) => {
                this.setState({ Cart: response.data });
                this.setState({ Amount: this.state.Amount + response.data.Total });
            })
            .catch((error) => {
                console.log(this.state.Amount);
            });
    }

    getPosts() {
        axios
            .get("http://localhost:5000/Cart/")
            .then((response) => {
                this.setState({ Cart: response.data });
            })
            .catch((error) => {
                console.log(error);
            });
    }

 

    CartList() {
        return this.state.Cart.map((currentCart) => {
            return ( <
                Cart Cart = { currentCart }
                deleteCart= { this.deleteCart }
                key = { currentCart._id }
                />
            );
        });
    }


    handleSearchArea = (e) => {
        const searchKey = e.currentTarget.value;

        axios.get("http://localhost:5000/Cart/").then((response) => {
            const resultt = response.data;
            const result = resultt.filter((props) =>
                props.Name.includes(searchKey)
            );

            this.setState({ Cart: result });
        });
    };

   

    render() {
        return ( 
            <div >
        <img src="https://i.ibb.co/rkfrhCm/banner18.webp" alt="" />
        

        <div className = "container" >

            <div  >
            
             </div> <br/ >
            <div className = "row" >
            <div  className = "col-9 mt-1 mb-1">
            <h3 > Cart List   </h3>
             </div > 
             <br></br>

             <br></br>
             <br></br>
             
              <div className = "col-lg-3 mt-1 mb-2" >
            <input className = "form-control" type = "search" placeholder = "Search Here" name = "searchQuery" onChange = { this.handleSearchArea } >
            </input>
             </div > 
              </div>
             
              <table class ="table table-bordered table-white">
            <thead className = "thead-light" >
            <tr >
            <th > Name </th> 
             < th > Cat </th> 
            <th > Price </th> 
             <th> Qty</th>
             <th > Total </th> 
             <th> Image</th>
            <th> Action </th > 
            </tr> </thead > 
            <tbody >  {
                this.state.Cart.map((props) => ( 
                    <tr key = { props.Name }>
                    <td > { props.Name } </td> 
                    <td > { props.Cat } </td> 
                    <td > <text>Rs.</text>{ props.Price }<text>.00</text> </td>
                     <td > { props.Qty } </td> 
                     <td > <text>Rs.</text>{ props.Total }<text>.00</text> </td> 
                    
                     <td><img src={`/uploads/${props.Image}`} width={160} alt='......'/></td>
                    <td >
                    < Link to = { "/Payment/" + props._id } >  <Button data-inline ="true" variant = "btn btn-primary" >Place Order & Pay</Button></Link > 
                    
                      </td> 
                      </ tr >))}  </tbody> </table > 
                      
          
           
            </div ></div>

        );
    }
}