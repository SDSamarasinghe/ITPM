import React, { Component } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Button } from "react-bootstrap";

const Store = (props) => ( 
    <tr>
    <td > { props.Store.No } </td> 
    <td> {props.Store.name} </td > { " " } 
    <td > { props.Store.id  } </td>{" "}
    <td > { props.Store.name } </td> 
    <td > { props.Store.age } </td> 
   

   
     </tr>
);

export default class StoreList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            Store: [],
        };
    }

    componentDidMount() {
        axios
            .get("http://localhost:5000/Payment/")
            .then((response) => {
                this.setState({ Store: response.data });
                
            })
            .catch((error) => {
                console.log(this.state.Amount);
            });
    }

    getPosts() {
        axios
            .get("http://localhost:5000/Payment/")
            .then((response) => {
                this.setState({ Store: response.data });
            })
            .catch((error) => {
                console.log(error);
            });
    }

 

    StoreList() {
        return this.state.Store.map((currentStore) => {
            return ( <
                Store Store = { currentStore }
                deleteStore= { this.deleteStore }
                key = { currentStore._id }
                />
            );
        });
    }


    handleSearchArea = (e) => {
        const searchKey = e.currentTarget.value;

        axios.get("http://localhost:5000/Payment/").then((response) => {
            const resultt = response.data;
            const result = resultt.filter((props) =>
                props.Item.includes(searchKey)
            );

            this.setState({ Store: result });
        });
    };
    myfunction(){
   
        window.print();
       }

   

    render() {
        return ( 
            <div >
       
        

        <div className = "container" >

            <div  >
            
             </div> <br/ >
            <div className = "row" >
            <div  className = "col-9 mt-1 mb-1">
            <h3 > Store Order Admin   </h3>
             </div > 
             <br></br>

             <br></br>
             <br></br>
             
              <div className = "col-lg-3 mt-1 mb-2" >
            <input className = "form-control" type = "search" placeholder = "Search Here" name = "searchQuery" onChange = { this.handleSearchArea } >
            </input>
             </div > 
              </div>
             
              <table class ="table table-bordered table-white">
            <thead className = "thead-light" >
            <tr >
            <th > Itme </th> 
             < th > Customer name </th> 
             <th > Total </th> 
             <th> Date</th>
           
            </tr> </thead > 
            <tbody >  {
                this.state.Store.map((props) => ( 
                    <tr key = { props.Item }>
                        
                    <td > { props.Item } </td> 
                    <td > { props.Cusname } </td> 
                    <td > <text>Rs.</text>{ props.Amount }<text>.00</text> </td>
                
                     <td > { props.Date }</td> 
                   
                      </ tr >))}  </tbody> </table > 
                      
          
           
            </div >
            
            <
            div style = {
                { float: 'right' }
            } >
            
            
            <Button type="button" class="btn btn-danger" id="1" variant = "primary"  onClick ={this.myfunction} > Print </Button>
            
            </div>
            <br></br>

            <br></br>
            <br></br>
            
            </div>

        );
    }
}