import React, { Component } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Button } from "react-bootstrap";

const vegetable = (props) => ( 
    <tr>
    <td > { props.vegetable.AppointmentNo } </td> 
    <td> {props.vegetable.Ownername} </td > { " " } 
    <td > { props.vegetable.Ownerid  } </td>{" "}
    <td > { props.vegetable.Petname } </td> 
    <td > { props.vegetable.Petage } </td> 
   

   
     </tr>
);

export default class vegetableList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            vegetable: [],
        };
    }

    componentDidMount() {
        axios
            .get("http://localhost:5000/vegetable/")
            .then((response) => {
                this.setState({ vegetable: response.data });
            })
            .catch((error) => {
                console.log(error);
            });
    }

    getPosts() {
        axios
            .get("http://localhost:5000/vegetable/")
            .then((response) => {
                this.setState({ vegetable: response.data });
            })
            .catch((error) => {
                console.log(error);
            });
    }

 

    vegetableList() {
        return this.state.vegetable.map((currentvegetable) => {
            return ( <
                vegetable vegetable = { currentvegetable }
                deletevegetable= { this.deletevegetable }
                key = { currentvegetable._id }
                />
            );
        });
    }


    handleSearchArea = (e) => {
        const searchKey = e.currentTarget.value;

        axios.get("http://localhost:5000/vegetable/").then((response) => {
            const resultt = response.data;
            const result = resultt.filter((props) =>
                props.Name.includes(searchKey)
            );

            this.setState({ vegetable: result });
        });
    };

   

    render() {
        return ( 
            <div >
        <img src="https://i.ibb.co/rkfrhCm/banner18.webp" alt="" />
        

        <div className = "container" >

            <div  >
            
             </div> <br/ >
            <div className = "row" >
            <div  className = "col-9 mt-1 mb-1">
            <h3 > All Vegetables   </h3>
             </div > 
             <br></br>

             <br></br>
             <br></br>
             
              <div className = "col-lg-3 mt-1 mb-2" >
            <input className = "form-control" type = "search" placeholder = "Search Here" name = "searchQuery" onChange = { this.handleSearchArea } >
            </input>
             </div > 
              </div>
             
              <table class ="table table-bordered table-white">
            <thead className = "thead-light" >
            <tr >
            <th > Name </th> 
             < th > Price </th> 
            <th > Description </th> 
             <th> Image</th>
            <th> Action </th > 
            </tr> </thead > 
            <tbody >  {
                this.state.vegetable.map((props) => ( 
                    <tr key = { props.Name }>
                    <td > { props.Name } </td> 
                    <td > <text>Rs.</text>{ props.Price }<text>.00</text> </td>
                     <td > { props.Description } </td> 
                     <td><img src={`/uploads/${props.Image}`} width={160} alt='......'/></td>
                          
                    <td >
                    < Link to = { "/Cart/" + props._id } >  <Button data-inline ="true" variant = "btn btn-primary" > Add To Cart </Button></Link > 
                    
                      </td>  </ tr >))}  </tbody> </table > 
                      
          
           
            </div ></div>

        );
    }
}