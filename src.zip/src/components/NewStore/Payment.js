import React, { Component } from 'react';
import axios from 'axios';
import "react-datepicker/dist/react-datepicker.css";
import swal from '@sweetalert/with-react'
import {  useParams } from 'react-router-dom';

export default class EditPayment extends Component {

    
    
    constructor(props) {
       
        super(props);
        this.onChangeFname = this.onChangeFname.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            Cusname:"",
            Name: "",
            Cat: "",
            Price:"",
            Image: "",
            Amount: "",
            Qty: "",
            Date: "",

           
            Payment: [],
        };

      

 
        
    } 
    
    
    
    componentDidMount() {
        
        axios.get('http://localhost:5000/cart/' + this.props.match.params.id)
            .then(response => {
                this.setState({
                    Name: response.data.Name,
                    Cat: response.data.Cat,
                    Price: response.data.Price,
                    Image: response.data.Image,
                    Amount: response.data.Total,
                    Qty: response.data.Qty
                })
            })
            .catch(function(error) {
                console.log(error);
                
            })

        axios.get('http://localhost:5000/cart/')
            .then(response => {
                if (response.data.length > 0) {
                    this.setState({
                        Payment: response.data.map(Payment => Payment.Name),
                    })
                }
            })
            .catch((error) => {
                console.log(error);
            })

    }

    onChangeFname(e) {
   
        this.setState({
            Cusname: e.target.value,
        });
      
        
    }





    onSubmit(e) {
        e.preventDefault();

            const Payment = {
                Cusname: this.state.Cusname,
                Item: this.state.Name,
                Amount:this.state.Amount,
                Date:Date()
               
            };
            console.log(Payment);

         

            axios.post('http://localhost:5000/Payment/add', Payment)
                .then((res) => console.log(res.data));

                axios.delete('http://localhost:5000/cart/' + this.props.match.params.id).then((response) => {
                console.log(response.data);
                });

            swal({
                title: "Done!",
                text: "Edit Successfully!",
                icon: "success",
                button: "Okay!",
            }).then((value) => {
                swal((window.location = "/Cartlist"));
            });
        
        }

    

    render() {
        return (<div  >
            <div class = "row ">
            <div class = "col-6" >
            <br/>
            <img src={`https://cdn.dribbble.com/users/1280935/screenshots/6974685/media/ec4c386222b837da0ff6eabec3f59ba3.gif`}  width="100%" height="80%" />
            </div> <div class = "col-6" >
            <div div class = "myformstyle" >
            <div className = "card-body" >
            <div className = "col-md-8 mt-4 mx-auto" > </div> 
            <h3 className = "text-center" > 
            <font face = "Comic sans MS" size = "6" > Enter You Payment Details </font>
            </h3 > <br></br> <h3 className = "text-Left" > 
            <font face = "Comic sans MS" size = "4" > Total : Rs.<text> {this.state.Amount}</text>.00</font>
            </h3 > <br></br>
            
            <br></br>
            
             <form onSubmit = { this.onSubmit } >

            <div className = "form-group" >
           
            <label >First Name: </label> 
           
            <input type = "text"
            required  className = "form-control"
            onChange = { this.onChangeFname }/>
             </div > 
            
            <div className = "form-group" >
            <label > Last name: </label> 
            <input type = "text"
            required  className = "form-control"
           />
             </div > 



             <div className = "form-group" >
            <label > Email: </label> 
            <input type = "email"
            required  className = "form-control"
            />
             </div > 

             <div className = "form-group" >
            <label > Card Number: </label> 
            <input type = "number"
            required  className = "form-control"
            />
             </div >
            

             <div className = "form-group" >
            <label > Expiretion Date: </label> 
            <input type = "Date"
            required  className = "form-control"
            />
             </div >


             <div className = "form-group" >
            <label > Cvv: </label> 
            <input type = "Number"
            required  className = "form-control"
            />
             </div >

            
            <div className = "form-group" >
            <input type = "submit"
            value = "Pay"
            className = "btn btn-primary" />
            </div>{" "} </form >  </div> </div > </div>
             </div ><br/> <br/>  </div>
        )
    }
}