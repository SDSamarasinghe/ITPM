import React, { Component } from 'react';
import axios from 'axios';
import "react-datepicker/dist/react-datepicker.css";
import swal from '@sweetalert/with-react'
import {  useParams } from 'react-router-dom';

export default class EditCart extends Component {

    
    
    constructor(props) {
       
        super(props);
       
       
        this.onChangeQty = this.onChangeQty.bind(this);
       
        
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            Name: "",
            Cat: "",
            Price:"",
            Description: "",
            Image: "",
            Total: "",
            Qty: "",
            
            Cart: [],
        };

 
        
    } 
    
    
    
    componentDidMount() {
        
        axios.get(`http://localhost:5000/vegetable/`+ this.props.match.params.id)
            .then(response => {
                this.setState({
                    Name: response.data.Name,
                    Cat: response.data.Cat,
                    Price: response.data.Price,
                    Description: response.data.Description,
                    Image: response.data.Image
                })
            })
            .catch(function(error) {
                console.log(error);
            })

        axios.get('http://localhost:5000/vegetable/')
            .then(response => {
                if (response.data.length > 0) {
                    this.setState({
                        Cart: response.data.map(Cart => Cart.Name),
                    })
                }
            })
            .catch((error) => {
                console.log(error);
            })

    }


//set qty




onChangeQty(e) {
    

    
    this.setState({
        Qty: e.target.value,
    });
    this.setState({ Total:e.target.value * this.state.Price});
}







    onSubmit(e) {
        e.preventDefault();

            const Cart = {
                Name: this.state.Name,
                Cat: this.state.Cat,
                Qty: this.state.Qty,
                Image: this.state.Image,
                Price: this.state.Price,
                Total:this.state.Total,
               
            };
            console.log(Cart);

         

            axios
                .post('http://localhost:5000/Cart/add', Cart)
                .then((res) => console.log(res.data));

            swal({
                title: "Done!",
                text: "Added To cart!",
                icon: "success",
                button: "Okay!",
            }).then((value) => {
                swal((window.location = "/Cartlist"));
            });
        
        }

    

    render() {
        return (<div  >
            <div class = "row ">
            <div class = "col-6" >
            <br/>
            <img src={`/uploads/${this.state.Image}`}  width="100%" height="80%" />
            </div> <div class = "col-6" >
            <div div class = "myformstyle" >
            <div className = "card-body" >
            <div className = "col-md-8 mt-4 mx-auto" > </div> 
            <h3 className = "text-center" > 
            <font face = "Comic sans MS" size = "6" > Add To cart </font>
            </h3 > <br></br>
            
            <br></br>
            
             <form onSubmit = { this.onSubmit } >

            <div className = "form-group" >
           
            <label >Name: </label> 
           
            <input type = "text"
            required  className = "form-control"
            value = { this.state.Name }
            disabled={true}
            />
             </div > 
            
            <div className = "form-group" >
            <label > Catagory: </label> 
            <input type = "text"
            disabled={true}
            required  className = "form-control"
            value = { this.state.Cat }/>
             </div > 



             <div className = "form-group" >
            <label > Price: </label> 
            <input type = "text"
            disabled={true}
            required  className = "form-control"
            value = { this.state.Price }/>
             </div > 

             <div className = "form-group" >
            <label > Description: </label> 
            <input type = "text"
            disabled={true}
            required  className = "form-control"
            value = { this.state.Description }/>
             </div >
            

             <div className = "form-group" >
            <label > Qty: </label> 
            <input type = "number"
            placeholder = "Qty"
            required  className = "form-control"
            value = { this.state.Qty }
            onChange = { this.onChangeQty }/>
             </div >


             <div className = "form-group" >
            <label > Total: </label> 
            <input type = "Number"
            placeholder = "Total"
            disabled={true}
            required  className = "form-control"
            value = { this.state.Total }
            onChange = { this.onChangeTcost }/>
             </div >

            

             

            <div className = "form-group" >
            <input type = "submit"
            value = "Add To Cart"
            className = "btn btn-primary" />
            </div>{" "} </form >  </div> </div > </div>
             </div ><br/> <br/>  </div>
        )
    }
}