import React, { Component } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Button } from "react-bootstrap";

const Fruit = (props) => ( 
    <tr>
    <td > { props.Fruit.AppointmentNo } </td> 
    <td> {props.Fruit.Ownername} </td > { " " } 
    <td > { props.Fruit.Ownerid  } </td>{" "}
    <td > { props.Fruit.Petname } </td> 
    <td > { props.Fruit.Petage } </td> 
   

   
     </tr>
);

export default class FruitList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            Fruit: [],
        };
    }

    componentDidMount() {
        axios
            .get("http://localhost:5000/Fruit/")
            .then((response) => {
                this.setState({ Fruit: response.data });
            })
            .catch((error) => {
                console.log(error);
            });
    }

    getPosts() {
        axios
            .get("http://localhost:5000/Fruit/")
            .then((response) => {
                this.setState({ Fruit: response.data });
            })
            .catch((error) => {
                console.log(error);
            });
    }

 

    FruitList() {
        return this.state.Fruit.map((currentFruit) => {
            return ( <
                Fruit Fruit = { currentFruit }
                deleteFruit= { this.deleteFruit }
                key = { currentFruit._id }
                />
            );
        });
    }


    handleSearchArea = (e) => {
        const searchKey = e.currentTarget.value;

        axios.get("http://localhost:5000/Fruit/").then((response) => {
            const resultt = response.data;
            const result = resultt.filter((props) =>
                props.Name.includes(searchKey)
            );

            this.setState({ Fruit: result });
        });
    };

   

    render() {
        return ( 
            <div >
        <img src="https://i.ibb.co/rkfrhCm/banner18.webp" alt="" />
        

        <div className = "container" >

            <div  >
            
             </div> <br/ >
            <div className = "row" >
            <div  className = "col-9 mt-1 mb-1">
            <h3 > All Fruits   </h3>
             </div > 
             <br></br>

             <br></br>
             <br></br>
             
              <div className = "col-lg-3 mt-1 mb-2" >
            <input className = "form-control" type = "search" placeholder = "Search Here" name = "searchQuery" onChange = { this.handleSearchArea } >
            </input>
             </div > 
              </div>
             
              <table class ="table table-bordered table-white">
            <thead className = "thead-light" >
            <tr >
            <th > Name </th> 
             < th > Price </th> 
            <th > Description </th> 
             <th> Image</th>
            <th> Action </th > 
            </tr> </thead > 
            <tbody >  {
                this.state.Fruit.map((props) => ( 
                    <tr key = { props.Name }>
                    <td > { props.Name } </td> 
                    <td > <text>Rs.</text>{ props.Price }<text>.00</text> </td>
                     <td > { props.Description } </td> 
                     <td><img src={`/uploads/${props.Image}`} width={160} alt='......'/></td>
                          
                    <td >
                    < Link to = { "/Cartfruit/" + props._id } >  <Button data-inline ="true" variant = "btn btn-primary" > Add To Cart </Button></Link > 
                    
                      </td>  </ tr >))}  </tbody> </table > 
                      
          
           
            </div ></div>

        );
    }
}