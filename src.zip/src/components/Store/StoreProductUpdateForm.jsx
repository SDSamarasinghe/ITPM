import React from "react";

const StoreProductUpdateForm = () => {
  return <div>StoreProductUpdateForm</div>;
};

export default StoreProductUpdateForm;
