const router = require('express').Router();
let Product = require('../models/Product.model');

router.route('/').get((req, res) => {
    Product.find()
        .then(Product => res.json(Product))
        .catch(err => res.status(400).json('Error: ' + err));
});


//Add Function

router.route('/add').post((req, res) => {

    const Supid = req.body.Supid;
    const Supcontact = req.body.Supcontact;
    const Pid = req.body.Pid;
    const Qty =req.body.Qty;
    const Pname = req.body.Pname;



    const newProduct = new Product({

        Supid,
        Supcontact,
        Pid,
        Qty,
        Pname,

    });



    newProduct.save()
        .then(() => res.json('Product added!'))
        .catch(err => res.status(400).json('Error: ' + err));
});


// Get Data 
router.route('/:id').get((req, res) => {
    Product.findById(req.params.id)
        .then(Product => res.json(Product))
        .catch(err => res.status(400).json('Error: ' + err));
});

//Delete Data

router.route('/:id').delete((req, res) => {
    Product.findByIdAndDelete(req.params.id)
        .then(() => res.json('Product deleted.'))
        .catch(err => res.status(400).json('Error: ' + err));
});


// Update data
router.route('/update/:id').post((req, res) => {
    Product.findById(req.params.id)
        .then(Product => {
            Product.Supid = req.body.Supid;
            Product.Supcontact = req.body.Supcontact;
            Product.Pid =req.body.Pid;
            Product.Pname = req.body.Pname;
            Product.Qty = req.body.Qty;


            Product.save()
                .then(() => res.json('Product updated!'))
                .catch(err => res.status(400).json('Error: ' + err));
        })
        .catch(err => res.status(400).json('Error: ' + err));
});


module.exports = router;