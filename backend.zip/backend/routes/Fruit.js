const router = require('express').Router();
let Fruit = require('../models/Fruit.model');

router.route('/').get((req, res) => {
    Fruit.find()
        .then(Fruit => res.json(Fruit))
        .catch(Fruit => res.status(400).json('Error: ' + err));
});


//Add Function

router.route('/add').post((req, res) => {

    const Name = req.body.Name;
    const Cat = req.body.Cat; 
    const Price = req.body.Price;
    const Description = req.body.Description;
    const Image = req.body.Image;



    const newFruit = new Fruit({
        Name,
        Cat,
        Price,
        Description,
        Image,
       

    });



    newFruit.save()
        .then(() => res.json('Fruit added!'))
        .catch(err => res.status(400).json('Error: ' + err));
});


// Get Data 
router.route('/:id').get((req, res) => {
    Fruit.findById(req.params.id)
        .then(Fruit => res.json(Fruit))
        .catch(err => res.status(400).json('Error: ' + err));
});







module.exports = router;