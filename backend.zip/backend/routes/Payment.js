const router = require("express").Router();
let Payment = require("../models/Payment.model");

router.route("/").get((req, res) => {
    Payment.find()
        .then((Payment) => res.json(Payment))
        .catch((err) => res.status(400).json("Error: " + err));
});

router.route("/add").post((req, res) => {
   
    const Item = req.body.Item;
    const Cusname = req.body.Cusname;
    const Amount = req.body.Amount;
    const Date = req.body.Date;

    const newPayment = new Payment({
      
        Item,
        Cusname,
        Amount,
        Date,
    });

    newPayment
        .save()
        .then(() => res.json("Payment Added!"))
        .catch((err) => res.status(400).json("Error: " + err));
});



module.exports = router;