const router = require('express').Router();
let Cart = require('../models/Cart.model');

router.route('/').get((req, res) => {
    Cart.find()
        .then(Cart => res.json(Cart))
        .catch(err => res.status(400).json('Error: ' + err));
});


//Add Function

router.route('/add').post((req, res) => {

    const Name = req.body.Name;
    const Cat = req.body.Cat;
    const Qty =req.body.Qty;
    const Image = req.body.Image;
    const Price = req.body.Price;
    const Total =req.body.Total;



    const newCart = new Cart({

        
        Name,
        Cat,
        Qty,
        Image,
        Price,
        Total,

    });



    newCart.save()
        .then(() => res.json('Cart added!'))
        .catch(err => res.status(400).json('Error: ' + err));
});


// Get Data 
router.route('/:id').get((req, res) => {
    Cart.findById(req.params.id)
        .then(Cart => res.json(Cart))
        .catch(err => res.status(400).json('Error: ' + err));
});


router.route("/:id").delete((req, res) => {
    Cart.findByIdAndDelete(req.params.id)
        .then(() => res.json("Cart deleted."))
        .catch((err) => res.status(400).json("Error: " + err));
});


module.exports = router;