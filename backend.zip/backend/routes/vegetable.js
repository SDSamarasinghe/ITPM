const router = require('express').Router();
let vegetable = require('../models/vegetable.model');

router.route('/').get((req, res) => {
    vegetable.find()
        .then(vegetable => res.json(vegetable))
        .catch(vegetable => res.status(400).json('Error: ' + err));
});


//Add Function

router.route('/add').post((req, res) => {

    const Name = req.body.Name;
    const Cat = req.body.Cat; 
    const Price = req.body.Price;
    const Description = req.body.Description;
    const Image = req.body.Image;



    const newvegetable = new vegetable({
        Name,
        Cat,
        Price,
        Description,
        Image,
       

    });



    newvegetable.save()
        .then(() => res.json('vegetable added!'))
        .catch(err => res.status(400).json('Error: ' + err));
});


// Get Data 
router.route('/:id').get((req, res) => {
    vegetable.findById(req.params.id)
        .then(vegetable => res.json(vegetable))
        .catch(err => res.status(400).json('Error: ' + err));
});

module.exports = router;